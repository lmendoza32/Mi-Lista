package com.example.milista

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var boton: Button = findViewById(R.id.button)
        var texto: TextView = findViewById(R.id.textView2)
        var lista: Spinner = findViewById(R.id.spinner)
        var listado = arrayListOf<String>()
        listado.add("Manzana")
        listado.add("Jitomate")
        listado.add("Cebolla")
        listado.add("Pollo")
        listado.add("Chuletas")
        listado.add("Frijoles")
        var adaptador = ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listado)
        lista.adapter = adaptador
        boton.setOnClickListener {
            texto.text = lista.selectedItem.toString()
        }
    }
}